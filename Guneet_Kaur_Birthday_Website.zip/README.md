# Guneet Kaur Birthday Website 🎂

A small birthday page for Guneet Kaur (November 4).

## Publish it free with GitHub Pages
1. Sign in to GitHub and create a new **public** repository, for example `guneet-birthday`.
2. Upload `index.html` from this folder to the repository root.
3. Open **Settings → Pages**.
4. Under “Build and deployment”, select **Deploy from a branch**.
5. Choose branch **main** and folder **/(root)**, then Save.
6. After GitHub Pages deploys, your shareable link will look like:
   `https://YOUR-GITHUB-USERNAME.github.io/guneet-birthday/`

Replace `YOUR-GITHUB-USERNAME` with your actual GitHub username.
